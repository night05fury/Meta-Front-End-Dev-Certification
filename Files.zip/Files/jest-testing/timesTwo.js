// Task 1: Code the timesTwo function declaration
function timesTwo(num) {
    var result = num * 2;
    return result;
}
module.exports = timesTwo;
// Task 2: Export the timesTwo function as a module
